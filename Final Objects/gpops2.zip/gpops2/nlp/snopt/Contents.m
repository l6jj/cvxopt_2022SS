%-----------------------------------------------------------------------------%
%                   SNOPT MATLAB Files for Use with GPOPS-II                  %
%-----------------------------------------------------------------------------%
% This directory contains a restricted version of SNOPT for use with GPOPS-II.%
% The required paths are set automatically by running the path setup script.  %
%-----------------------------------------------------------------------------%
