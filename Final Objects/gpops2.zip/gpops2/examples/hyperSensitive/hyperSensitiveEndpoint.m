%---------------------------------%
% BEGIN: hyperSensitiveEndpoint.m %
%---------------------------------%
function output = hyperSensitiveEndpoint(input)

q  = input.phase.integral;
output.objective = q;
%---------------------------------%
% BEGIN: hyperSensitiveEndpoint.m %
%---------------------------------%
