function y= sat(x)
y=x/(abs(x)+0.001);
end