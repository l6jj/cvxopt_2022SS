function objective = gpopsIpoptObjRPMD(Zin, probinfo)

% evaluate objective
objective = gpopsObjRPMD(Zin, probinfo);