function objective = gpopsIpoptObjRPMI(Zin, probinfo)

% evaluate objective
objective = gpopsObjRPMI(Zin, probinfo);